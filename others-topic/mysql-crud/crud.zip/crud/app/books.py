from .database import connect_db

def create_book(title, author_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO books (title, author_id) VALUES (?, ?)', (title, author_id))
    conn.commit()
    conn.close()


def update_book(book_id, new_title):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE books SET title = ? WHERE id = ?', (new_title, book_id))
    conn.commit()
    conn.close()


def delete_books_by_author(author_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM books WHERE author_id = ?', (author_id,))
    conn.commit()
    conn.close()


def get_books_and_authors():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT books.title, authors.name
        FROM books
        JOIN authors ON books.author_id = authors.id
    ''')
    books_and_authors = cursor.fetchall()
    conn.close()
    return books_and_authors

def get_books_from_multiple_authors():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT title FROM books WHERE author_id IN (SELECT id FROM authors WHERE name LIKE 'J.K. Rowling')
        UNION
        SELECT title FROM books WHERE author_id IN (SELECT id FROM authors WHERE name LIKE 'Harper Lee')
    ''')
    books_from_multiple_authors = cursor.fetchall()
    conn.close()
    return books_from_multiple_authors