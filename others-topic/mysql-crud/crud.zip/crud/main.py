# main.py
from app.database import connect_db, create_tables
from app.authors import create_author
from app.books import create_book, delete_books_by_author, update_book, get_books_and_authors,get_books_from_multiple_authors

def display_menu():
    print("Choose an operation:")
    print("1. Create authors and books")
    print("2. Update book title")
    print("3. Delete books by author ID")
    print("4. Get books and authors")
    print("5. Get books from multiple authors")
    print("6. Exit")

def main():
    conn = connect_db()
    create_tables(conn)

    while True:
        display_menu()
        choice = input("Enter your choice: ")

        if choice == '1':
            create_author("J.K. Rowling")
            create_author("Harper Lee")

            create_book("Harry Potter and the Sorcerer's Stone", 1)
            create_book("To Kill a Mockingbird", 2)

        elif choice == '2':
            book_id = int(input("Enter the book ID to update: "))
            new_title = input("Enter the new book title: ")
            update_book(book_id, new_title)

        elif choice == '3':
            author_id = int(input("Enter the author ID to delete books: "))
            delete_books_by_author(author_id)

        elif choice == '4':
            books_and_authors = get_books_and_authors()
            for book, author in books_and_authors:
                print(f"Book: {book}, Author: {author}")

        elif choice == '5':
            books_from_multiple_authors = get_books_from_multiple_authors()
            for book in books_from_multiple_authors:
                print(f"Book: {book}")

        elif choice == '6':
            print("Exiting the program.")
            break

        else:
            print("Invalid choice. Please select a valid option.")

    conn.close()

if __name__ == "__main__":
    main()